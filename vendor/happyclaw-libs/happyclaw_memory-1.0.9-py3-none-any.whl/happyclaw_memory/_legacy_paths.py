"""Pre-rename (Octop-era) data locations, read once and then retired.

This is the only module in the package allowed to spell the old product name, and
the reason is mechanical: a migration cannot copy a directory whose name it is
not allowed to know. Everything here is **copy-only** — current code never writes
to a legacy location.

What happens on first run: :func:`ensure_home_dirs` copies each legacy directory
to its current name when the current one does not exist yet, and leaves the
legacy directory in place. Deleting a user's durable data is not a rename side
effect, so removing the leftover is the user's call and the migration says so in
the log line it emits.

The copy is not resumable in a fancy way: ``copytree`` either finishes or raises,
and a raised copy means the current directory does not exist, so the next start
retries. Re-running after a *successful* migration is a no-op, both because the
current directory now exists and because a per-process memo short-circuits it. If
a user deletes the current directory but keeps the leftover, the next start
copies it back — that is data recovery, not a bug.

The portable-adoption scanner keeps the legacy globs in
:data:`LEGACY_SCAN_GLOBS` so a host upgrading from the old layout can still find
and adopt its old stores.
"""

from __future__ import annotations

import logging
import shutil
from collections.abc import Sequence
from pathlib import Path
from typing import Final

logger = logging.getLogger("happyclaw_memory")

HOMEDIR_PAIRS: Final[tuple[tuple[str, str], ...]] = (
    ("~/.octop-memory", "~/.happyclaw-memory"),
    ("~/.octopmemory", "~/.happyclawmemory"),
    ("~/.octop", "~/.happyclaw"),
    ("~/.octop-harness", "~/.happyclaw-harness"),
    ("~/.openclaw/octopmemory", "~/.openclaw/happyclawmemory"),
    ("~/.hermes/octopmemory", "~/.hermes/happyclawmemory"),
)
"""``(legacy, current)`` home-relative directory pairs."""

LEGACY_SCAN_GLOBS: Final[tuple[str, ...]] = (
    "~/.octop-memory/*/memory.sqlite",
    "~/.octop/agents/*/memory.sqlite",
    "~/.octop-harness/*/memory.sqlite",
    "~/.octopmemory/*/memory.sqlite",
    "~/.hermes/octopmemory/memory.sqlite",
    "~/.openclaw/octopmemory/*/memory.sqlite",
)
"""Legacy store locations the portable-adoption scan should still consider."""

HERMES_LEGACY_DIR = "octopmemory"
HERMES_CURRENT_DIR = "happyclawmemory"
HERMES_LEGACY_CONFIG = "octopmemory.json"
HERMES_CURRENT_CONFIG = "happyclawmemory.json"

_done: set[str] = set()


def _copy_once(legacy: Path, current: Path) -> bool:
    """Copy ``legacy`` to ``current`` when only the legacy one exists."""
    if current.exists() or not legacy.exists():
        return False
    shutil.copytree(legacy, current)
    logger.warning(
        "happyclaw-memory: migrated data from %s to %s. The old directory is a leftover and can be "
        "deleted once you have confirmed the new one works.",
        legacy,
        current,
    )
    _done.add(str(current))
    return True


def ensure_home_dirs(pairs: Sequence[tuple[str, str]] = HOMEDIR_PAIRS) -> list[tuple[Path, Path]]:
    """Migrate every legacy home directory that has not been migrated yet.

    Returns the pairs actually copied, so a caller or a test can report what
    happened. A directory that already exists under its current name is left
    alone and the legacy copy is not consulted.
    """
    moved: list[tuple[Path, Path]] = []
    for legacy_ref, current_ref in pairs:
        legacy = Path(legacy_ref).expanduser()
        current = Path(current_ref).expanduser()
        if str(current) in _done:
            continue
        if _copy_once(legacy, current):
            moved.append((legacy, current))
    return moved


def ensure_hermes_dir(hermes_home: Path) -> Path:
    """Return ``$HERMES_HOME/happyclawmemory``, migrating ``octopmemory`` into it."""
    root = Path(hermes_home).expanduser()
    current = root / HERMES_CURRENT_DIR
    _copy_once(root / HERMES_LEGACY_DIR, current)
    return current


def ensure_hermes_config(hermes_home: Path) -> Path:
    """Return ``$HERMES_HOME/happyclawmemory.json``, copying the legacy file if needed."""
    root = Path(hermes_home).expanduser()
    current = root / HERMES_CURRENT_CONFIG
    legacy = root / HERMES_LEGACY_CONFIG
    if not current.exists() and legacy.exists():
        shutil.copy2(legacy, current)
        logger.warning(
            "happyclaw-memory: migrated Hermes config from %s to %s. The old file is a leftover.",
            legacy,
            current,
        )
    return current


__all__ = [
    "HERMES_CURRENT_CONFIG",
    "HERMES_CURRENT_DIR",
    "HERMES_LEGACY_CONFIG",
    "HERMES_LEGACY_DIR",
    "HOMEDIR_PAIRS",
    "LEGACY_SCAN_GLOBS",
    "ensure_hermes_config",
    "ensure_hermes_dir",
    "ensure_home_dirs",
]
