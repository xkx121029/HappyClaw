"""Caller-facing recall quality knobs.

Every field defaults to the value the pipeline already used, so a caller who
passes nothing gets byte-identical behaviour. The point of the bundle is that a
self-hosting user tunes recall from configuration instead of a code edit: build
one with :meth:`RecallTuning.from_config` and splat :meth:`to_recall_kwargs`
into :func:`happyclaw_memory.pipeline.recall.recall_for_prompt`.

``limit`` is the top-k the caller sees, ``suppress_threshold`` is the Jaccard
cut for near-duplicate suppression, ``per_entity_cap`` bounds how many snippets
one entity may contribute, and ``recency_half_life_days`` is the recency decay
half-life in the reranker. Raising the half-life keeps older facts competitive;
0.85 suppression is "near-identical only", so lowering it drops merely similar
facts — that is a quality trade the user should make knowingly.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from happyclaw_memory.pipeline.recall.rerank import HALF_LIFE_DAYS

DEFAULT_LIMIT = 5
"""Top-k snippets returned when no caller override is present."""

DEFAULT_SUPPRESS_THRESHOLD = 0.85
"""Jaccard similarity at which two snippets count as near-duplicates."""

DEFAULT_PER_ENTITY_CAP = 3
"""Maximum snippets any single entity may contribute to one recall."""


def _positive_int(value: Any, default: int, name: str) -> int:
    if value is None:
        return default
    if isinstance(value, bool) or not isinstance(value, int) or value < 1:
        raise ValueError(f"recall.{name} must be a positive integer, got {value!r}")
    return value


def _bounded_float(value: Any, default: float, name: str, *, upper: float | None = None) -> float:
    if value is None:
        return default
    if isinstance(value, bool) or not isinstance(value, int | float):
        raise ValueError(f"recall.{name} must be a number, got {value!r}")
    number = float(value)
    if number <= 0.0:
        raise ValueError(f"recall.{name} must be positive, got {value!r}")
    if upper is not None and number > upper:
        raise ValueError(f"recall.{name} must be at most {upper}, got {value!r}")
    return number


@dataclass(frozen=True)
class RecallTuning:
    """The four knobs that change recall quality, with the legacy defaults."""

    limit: int = DEFAULT_LIMIT
    suppress_threshold: float = DEFAULT_SUPPRESS_THRESHOLD
    per_entity_cap: int = DEFAULT_PER_ENTITY_CAP
    recency_half_life_days: float = HALF_LIFE_DAYS

    def __post_init__(self) -> None:
        if isinstance(self.limit, bool) or self.limit < 1:
            raise ValueError("limit must be a positive integer")
        if isinstance(self.per_entity_cap, bool) or self.per_entity_cap < 1:
            raise ValueError("per_entity_cap must be a positive integer")
        if not 0.0 <= self.suppress_threshold <= 1.0:
            raise ValueError("suppress_threshold must be within [0, 1]")
        if self.recency_half_life_days <= 0.0:
            raise ValueError("recency_half_life_days must be positive")

    @classmethod
    def from_config(cls, config: dict[str, Any] | None) -> RecallTuning:
        """Build from a merged ``recall`` config block.

        Unknown keys are ignored so a config written for a newer release still
        loads. ``default_max_results`` is the key the runtime already uses for
        top-k, so it is reused rather than introducing a second name for it.
        """
        cfg = dict(config or {})
        return cls(
            limit=_positive_int(cfg.get("default_max_results"), DEFAULT_LIMIT, "default_max_results"),
            suppress_threshold=_bounded_float(
                cfg.get("suppress_threshold"), DEFAULT_SUPPRESS_THRESHOLD, "suppress_threshold", upper=1.0
            ),
            per_entity_cap=_positive_int(cfg.get("per_entity_cap"), DEFAULT_PER_ENTITY_CAP, "per_entity_cap"),
            recency_half_life_days=_bounded_float(
                cfg.get("recency_half_life_days"), HALF_LIFE_DAYS, "recency_half_life_days"
            ),
        )

    def to_recall_kwargs(self) -> dict[str, Any]:
        """Keyword arguments for :func:`recall_for_prompt`."""
        return {
            "limit": self.limit,
            "suppress_threshold": self.suppress_threshold,
            "per_entity_cap": self.per_entity_cap,
            "recency_half_life_days": self.recency_half_life_days,
        }


__all__ = [
    "DEFAULT_LIMIT",
    "DEFAULT_PER_ENTITY_CAP",
    "DEFAULT_SUPPRESS_THRESHOLD",
    "RecallTuning",
]
