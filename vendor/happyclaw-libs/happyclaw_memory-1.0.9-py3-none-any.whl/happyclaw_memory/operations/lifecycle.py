"""Memory lifecycle: see what is remembered, forget it precisely, move it in and out.

An agent memory that only grows is unusable for the person self-hosting it: they
cannot see what was kept about them, cannot remove it, and cannot move it to
another machine. Each entry point answers exactly one of those:

- :func:`list_memories` — "what do you remember about this, and from when?"
- :func:`forget` — "drop it", with a dry run that lists every row first.
- :func:`export_memories` / :func:`import_memories` — "back it up, or move it".

**Forget is a real delete, not a deprecation.** ``Memory.deprecate_atom`` keeps
the assertion text and only removes it from recall, so a user who is told
"forgotten" and can still grep the text out of the database file has been lied
to. :func:`forget` removes the atom row, its memory-tree leaf, the candidate row
that carries the same text, its vector-index entry, and every raw event that no
surviving atom or candidate still cites. Full-text search follows automatically:
SQLite has ``AFTER DELETE`` triggers for every FTS table and Postgres regenerates
its ``tsvector`` column, so neither leaves a ghost hit behind.

The dry run and the real run are the same plan: :func:`forget` computes the
complete :class:`ForgetPlan` first and only then executes it, so what a preview
lists is exactly what a subsequent run deletes.
"""

from __future__ import annotations

import hashlib
import json
import uuid
from collections import Counter
from dataclasses import dataclass, field, replace
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any, Literal

from happyclaw_memory.types import (
    Alias,
    AtomCard,
    Candidate,
    Entity,
    EntityType,
    ImportanceLevel,
    JournalEntry,
    RawEvent,
)

if TYPE_CHECKING:
    from happyclaw_memory.core import Memory

SCAN_LIMIT = 2_147_483_647
"""Row cap for full scans. Same value the retention audit uses; SQLite's own
``LIMIT`` maximum, so it reads as "everything"."""

_JOURNAL_ID_CAP = 500
"""Ids recorded per journal entry before the list is truncated."""

EXPORT_SCHEMA = "happyclaw-memory/export"
EXPORT_SCHEMA_VERSION = 1
"""JSONL export format identity. A reader must refuse an unknown version rather
than guess, because field meanings are only stable within one schema version."""


# ---------------------------------------------------------------------------
# Filters
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class MemoryFilter:
    """The selector shared by :func:`list_memories` and :func:`forget`.

    Times are inclusive and compared against ``occurred_at`` (when the fact
    happened), not ``created_at`` (when it was written), because that is the
    axis a person reasons about. Naive datetimes are read as UTC rather than
    compared as strings, so a naive filter cannot silently miss rows.
    """

    since: datetime | None = None
    until: datetime | None = None
    entity_id: str | None = None
    entity_name: str | None = None
    kind: str | None = None
    importance: ImportanceLevel | None = None
    include_deprecated: bool = False

    def __post_init__(self) -> None:
        if self.entity_id is not None and self.entity_name is not None:
            raise ValueError("pass entity_id or entity_name, not both")
        if self.since is not None and self.until is not None and _as_utc(self.since) > _as_utc(self.until):
            raise ValueError("since must not be after until")

    @property
    def has_selector(self) -> bool:
        return any(
            value is not None
            for value in (self.since, self.until, self.entity_id, self.entity_name, self.kind, self.importance)
        )


# ---------------------------------------------------------------------------
# Records and reports
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class MemoryRecord:
    """One remembered fact, flattened for listing and previewing.

    ``kind`` is the producing candidate's type (Fact / Decision / Task /
    Preference). It is resolved with one extra candidate read per row, which is
    why :func:`list_memories` is a bounded administrative call and not something
    to run inside a recall path.
    """

    atom_id: str
    entity_id: str
    entity_name: str
    entity_type: EntityType
    kind: str
    assertion: str
    importance: ImportanceLevel
    confidence: str
    occurred_at: datetime
    created_at: datetime
    deprecated_at: datetime | None
    raw_event_ids: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        return {
            "atom_id": self.atom_id,
            "entity_id": self.entity_id,
            "entity_name": self.entity_name,
            "entity_type": self.entity_type,
            "kind": self.kind,
            "assertion": self.assertion,
            "importance": self.importance,
            "confidence": self.confidence,
            "occurred_at": self.occurred_at.isoformat(),
            "created_at": self.created_at.isoformat(),
            "deprecated_at": self.deprecated_at.isoformat() if self.deprecated_at else None,
            "raw_event_ids": list(self.raw_event_ids),
        }


@dataclass(frozen=True)
class ForgetPlan:
    """Exactly what a forget call deletes.

    Returned unchanged by a dry run, and returned by the real run with
    ``dry_run`` / ``applied`` flipped, so a caller can assert that the preview
    and the execution describe the same rows.
    """

    atoms: tuple[MemoryRecord, ...] = ()
    leaf_node_ids: tuple[str, ...] = ()
    candidate_ids: tuple[str, ...] = ()
    raw_event_ids: tuple[str, ...] = ()
    dry_run: bool = True
    applied: bool = False
    notes: tuple[str, ...] = ()

    @property
    def matched(self) -> int:
        return len(self.atoms)

    def summary(self) -> dict[str, int]:
        return {
            "atoms": len(self.atoms),
            "leaf_nodes": len(self.leaf_node_ids),
            "candidates": len(self.candidate_ids),
            "raw_events": len(self.raw_event_ids),
        }


@dataclass(frozen=True)
class ExportReport:
    path: Path
    records: int
    counts: dict[str, int] = field(default_factory=dict)
    checksum: str = ""
    bytes_written: int = 0


@dataclass(frozen=True)
class ImportReport:
    path: Path
    imported: int
    skipped: int
    counts: dict[str, int] = field(default_factory=dict)
    checksum: str = ""
    dry_run: bool = False


# ---------------------------------------------------------------------------
# Time helpers
# ---------------------------------------------------------------------------


def _as_utc(value: datetime) -> datetime:
    """Read a naive datetime as UTC so comparisons never mix aware and naive."""
    return value.replace(tzinfo=UTC) if value.tzinfo is None else value.astimezone(UTC)


def _iso(value: datetime | None) -> str | None:
    return value.isoformat() if value is not None else None


def _parse_dt(value: object) -> datetime | None:
    if not isinstance(value, str) or not value:
        return None
    return datetime.fromisoformat(value)


# ---------------------------------------------------------------------------
# Listing
# ---------------------------------------------------------------------------


def _resolve_entity(memory: Memory, flt: MemoryFilter) -> tuple[bool, str | None]:
    """Resolve ``entity_name`` to an entity id.

    Returns ``(resolved, entity_id)``. An unknown name resolves to "no rows"
    rather than to "no filter" — otherwise a typo in a forget filter would
    quietly widen the match set.
    """
    if flt.entity_name is None:
        return True, flt.entity_id
    entity = memory.find_entity_by_name(flt.entity_name)
    if entity is None:
        return False, None
    return True, entity.id


def _select(memory: Memory, flt: MemoryFilter, *, limit: int) -> list[AtomCard]:
    resolved, entity_id = _resolve_entity(memory, flt)
    if not resolved:
        return []
    return memory.list_atoms(
        entity_id=entity_id,
        importance=flt.importance,
        include_deprecated=flt.include_deprecated,
        limit=limit,
        since=flt.since,
        until=flt.until,
        kind=flt.kind,
    )


def _records(memory: Memory, atoms: list[AtomCard]) -> list[MemoryRecord]:
    entities: dict[str, Entity | None] = {}
    kinds: dict[str, str] = {}
    out: list[MemoryRecord] = []
    for atom in atoms:
        if atom.entity_id not in entities:
            entities[atom.entity_id] = memory.get_entity(atom.entity_id)
        entity = entities[atom.entity_id]
        if atom.candidate_id not in kinds:
            candidate = memory.get_candidate(atom.candidate_id)
            kinds[atom.candidate_id] = candidate.candidate_type if candidate else "Fact"
        raw_ids = tuple(dict.fromkeys([*atom.raw_event_ids, atom.quote_event_id]))
        out.append(
            MemoryRecord(
                atom_id=atom.id,
                entity_id=atom.entity_id,
                entity_name=entity.canonical_name if entity else "",
                entity_type=entity.entity_type if entity else "Fact",
                kind=kinds[atom.candidate_id],
                assertion=atom.assertion,
                importance=atom.importance,
                confidence=atom.confidence,
                occurred_at=atom.occurred_at,
                created_at=atom.created_at,
                deprecated_at=atom.deprecated_at,
                raw_event_ids=raw_ids,
            )
        )
    return out


def list_memories(
    memory: Memory,
    *,
    since: datetime | None = None,
    until: datetime | None = None,
    entity_id: str | None = None,
    entity_name: str | None = None,
    kind: str | None = None,
    importance: ImportanceLevel | None = None,
    include_deprecated: bool = False,
    limit: int = 100,
) -> list[MemoryRecord]:
    """List remembered facts newest-first, filtered by time, entity or kind."""
    flt = MemoryFilter(
        since=since,
        until=until,
        entity_id=entity_id,
        entity_name=entity_name,
        kind=kind,
        importance=importance,
        include_deprecated=include_deprecated,
    )
    return _records(memory, _select(memory, flt, limit=limit))


# ---------------------------------------------------------------------------
# Forget
# ---------------------------------------------------------------------------


def _plan_for(memory: Memory, atoms: list[AtomCard]) -> ForgetPlan:
    """Turn a selected atom set into a complete, self-contained delete plan.

    Nothing is written here, which is what makes the dry run trustworthy: the
    same call produces the plan the executor later runs.
    """
    selected = {atom.id for atom in atoms}
    if not selected:
        return ForgetPlan()

    live = {atom.id: atom for atom in memory.list_atoms(limit=SCAN_LIMIT, include_deprecated=True)}
    surviving_atoms = [atom for atom_id, atom in live.items() if atom_id not in selected]
    candidates = {candidate.id: candidate for candidate in memory.list_candidates(limit=SCAN_LIMIT)}
    doomed_candidates = {atom.candidate_id for atom in atoms if atom.candidate_id} & set(candidates)
    surviving_candidates = [c for cand_id, c in candidates.items() if cand_id not in doomed_candidates]

    cited_by_atoms: set[str] = set()
    for atom in surviving_atoms:
        cited_by_atoms.update(atom.raw_event_ids)
        cited_by_atoms.add(atom.quote_event_id)
    cited_by_candidates: set[str] = set()
    for candidate in surviving_candidates:
        cited_by_candidates.update(candidate.raw_event_ids)
        cited_by_candidates.add(candidate.quote_event_id)
    keep = cited_by_atoms | cited_by_candidates

    doomed_raw: list[str] = []
    for atom in atoms:
        for raw_id in [*atom.raw_event_ids, atom.quote_event_id]:
            if raw_id in keep or raw_id in doomed_raw:
                continue
            doomed_raw.append(raw_id)

    leaf_ids: list[str] = []
    for atom in atoms:
        node = memory.backend.get_node_by_atom_id(atom.id)
        if node is not None:
            leaf_ids.append(node.id)
    shared_leaf = sum(1 for node_id in leaf_ids if memory.backend.get_children(node_id))
    kept_raw = {raw_id for atom in atoms for raw_id in [*atom.raw_event_ids, atom.quote_event_id]} & keep
    notes: list[str] = []
    if shared_leaf:
        notes.append(f"{shared_leaf} leaf node(s) kept a child subtree; children are untouched")
    if kept_raw:
        notes.append(f"{len(kept_raw)} raw event(s) kept: still cited by surviving atoms or candidates")

    return ForgetPlan(
        atoms=tuple(_records(memory, atoms)),
        leaf_node_ids=tuple(sorted(leaf_ids)),
        candidate_ids=tuple(sorted(doomed_candidates)),
        raw_event_ids=tuple(sorted(doomed_raw)),
        notes=tuple(notes),
    )


def _execute(memory: Memory, plan: ForgetPlan, *, actor: Literal["user", "auto", "rule"], note: str) -> ForgetPlan:
    """Delete exactly the rows the plan names, in one transaction."""
    if not plan.atoms:
        return replace(plan, dry_run=False, applied=False)
    now = datetime.now(UTC)
    counts = Counter(record.entity_id for record in plan.atoms)
    with memory.backend.transaction():
        for record in plan.atoms:
            memory.backend.delete_atom(record.atom_id)
        for node_id in plan.leaf_node_ids:
            memory.backend.delete_node(node_id)
        for candidate_id in plan.candidate_ids:
            memory.backend.delete_candidate(candidate_id)
        for raw_id in plan.raw_event_ids:
            memory.backend.delete_raw(raw_id)
        for entity_id, removed in counts.items():
            memory.backend.bump_entity_atom_count(entity_id, delta=-removed)
            memory.backend.mark_entity_page_dirty(entity_id, when=now)
        memory.append_journal(
            JournalEntry(
                id=str(uuid.uuid4()),
                timestamp=now,
                action="forget",
                actor=actor,
                before={"counts": plan.summary()},
                after={
                    "atom_ids": [r.atom_id for r in plan.atoms][:_JOURNAL_ID_CAP],
                    "raw_event_ids": list(plan.raw_event_ids)[:_JOURNAL_ID_CAP],
                    "candidate_ids": list(plan.candidate_ids)[:_JOURNAL_ID_CAP],
                    "truncated": len(plan.atoms) > _JOURNAL_ID_CAP,
                },
                note=note,
            )
        )
    for record in plan.atoms:
        memory._drop_atom_vector(record.atom_id)
    return replace(plan, dry_run=False, applied=True)


def forget_atoms(
    memory: Memory,
    atom_ids: list[str],
    *,
    actor: Literal["user", "auto", "rule"] = "user",
    note: str = "Forget requested",
    dry_run: bool = True,
) -> ForgetPlan:
    """Forget an explicit atom-id set. Shared by :func:`forget` and retention."""
    atoms = [atom for atom in (memory.get_atom(atom_id) for atom_id in dict.fromkeys(atom_ids)) if atom is not None]
    plan = _plan_for(memory, atoms)
    if dry_run:
        return plan
    return _execute(memory, plan, actor=actor, note=note)


def forget(
    memory: Memory,
    *,
    since: datetime | None = None,
    until: datetime | None = None,
    entity_id: str | None = None,
    entity_name: str | None = None,
    kind: str | None = None,
    importance: ImportanceLevel | None = None,
    include_deprecated: bool = True,
    dry_run: bool = True,
    actor: Literal["user", "auto", "rule"] = "user",
    note: str = "Forget requested",
    everything: bool = False,
) -> ForgetPlan:
    """Delete every fact matching the selector, after showing exactly what goes.

    ``dry_run=True`` is the default, so a caller has to ask twice before data
    disappears. A call with no selector raises instead of matching everything —
    wipe-everything has to say ``everything=True`` out loud.
    """
    flt = MemoryFilter(
        since=since,
        until=until,
        entity_id=entity_id,
        entity_name=entity_name,
        kind=kind,
        importance=importance,
        include_deprecated=include_deprecated,
    )
    if not flt.has_selector and not everything:
        raise ValueError(
            "forget() needs at least one of since/until/entity_id/entity_name/kind/importance, "
            "or everything=True to match every fact"
        )
    if everything and flt.has_selector:
        raise ValueError("pass either a selector or everything=True, not both")
    plan = _plan_for(memory, _select(memory, flt, limit=SCAN_LIMIT))
    if dry_run:
        return plan
    return _execute(memory, plan, actor=actor, note=note)


# ---------------------------------------------------------------------------
# Export / import (JSONL)
# ---------------------------------------------------------------------------


def _entity_row(entity: Entity) -> dict[str, Any]:
    return {
        "type": "entity",
        "id": entity.id,
        "entity_type": entity.entity_type,
        "canonical_name": entity.canonical_name,
        "aliases": list(entity.aliases),
        "atom_count": entity.atom_count,
        "created_at": _iso(entity.created_at),
        "last_promoted_at": _iso(entity.last_promoted_at),
    }


def _alias_row(alias: Alias) -> dict[str, Any]:
    return {
        "type": "alias",
        "alias": alias.alias,
        "entity_id": alias.entity_id,
        "entity_type": alias.entity_type,
        "created_by": alias.created_by,
        "created_at": _iso(alias.created_at),
    }


def _raw_row(event: RawEvent) -> dict[str, Any]:
    return {
        "type": "raw_event",
        "id": event.id,
        "host": event.host,
        "session_id": event.session_id,
        "thread_id": event.thread_id,
        "user": event.user,
        "timestamp": _iso(event.timestamp),
        "event_type": event.event_type,
        "content": event.content,
        "payload": dict(event.payload),
    }


def _candidate_row(candidate: Candidate) -> dict[str, Any]:
    return {
        "type": "candidate",
        "id": candidate.id,
        "raw_event_ids": list(candidate.raw_event_ids),
        "candidate_type": candidate.candidate_type,
        "status": candidate.status,
        "title": candidate.title,
        "assertion": candidate.assertion,
        "verbatim_quote": candidate.verbatim_quote,
        "quote_event_id": candidate.quote_event_id,
        "subject_name": candidate.subject_name,
        "subject_entity_type": candidate.subject_entity_type,
        "target_entity_id": candidate.target_entity_id,
        "confidence": candidate.confidence,
        "importance": candidate.importance,
        "recommended_action": candidate.recommended_action,
        "promotion_reason": candidate.promotion_reason,
        "extractor_version": candidate.extractor_version,
        "created_at": _iso(candidate.created_at),
        "decided_at": _iso(candidate.decided_at),
        "decided_by": candidate.decided_by,
        "session_id": candidate.session_id,
        "payload": dict(candidate.payload),
    }


def _atom_row(atom: AtomCard) -> dict[str, Any]:
    return {
        "type": "atom",
        "id": atom.id,
        "entity_id": atom.entity_id,
        "candidate_id": atom.candidate_id,
        "raw_event_ids": list(atom.raw_event_ids),
        "assertion": atom.assertion,
        "verbatim_quote": atom.verbatim_quote,
        "quote_event_id": atom.quote_event_id,
        "search_terms": list(atom.search_terms),
        "occurred_at": _iso(atom.occurred_at),
        "confidence": atom.confidence,
        "importance": atom.importance,
        "created_at": _iso(atom.created_at),
        "superseded_by": atom.superseded_by,
        "deprecated_at": _iso(atom.deprecated_at),
    }


def _dump(row: dict[str, Any]) -> str:
    return json.dumps(row, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _checksum(body: list[str]) -> str:
    return hashlib.sha256(("\n".join(body) + "\n").encode("utf-8")).hexdigest()


def export_memories(memory: Memory, path: str | Path, *, created_at: datetime | None = None) -> ExportReport:
    """Write every remembered fact to a JSONL file with a versioned header.

    Rows are ordered entity → alias → raw_event → candidate → atom, sorted by id
    within each type, so two exports of the same data are byte-identical.
    ``created_at`` pins the header timestamp; pass it in tests that want to
    compare two files for equality.
    """
    rows: list[dict[str, Any]] = []
    rows.extend(_entity_row(entity) for entity in memory.list_entities(limit=SCAN_LIMIT))
    rows.extend(_alias_row(alias) for alias in memory.list_aliases(limit=SCAN_LIMIT))
    rows.extend(_raw_row(event) for event in memory.list_raw(limit=SCAN_LIMIT))
    rows.extend(_candidate_row(candidate) for candidate in memory.list_candidates(limit=SCAN_LIMIT))
    rows.extend(_atom_row(atom) for atom in memory.list_atoms(limit=SCAN_LIMIT, include_deprecated=True))

    order = {"entity": 0, "alias": 1, "raw_event": 2, "candidate": 3, "atom": 4}
    rows.sort(key=lambda row: (order[str(row["type"])], str(row.get("id") or row.get("alias"))))

    counts = dict(Counter(str(row["type"]) for row in rows))
    header = {
        "type": "header",
        "schema": EXPORT_SCHEMA,
        "schema_version": EXPORT_SCHEMA_VERSION,
        "namespace": memory.namespace,
        "created_at": _iso(created_at or datetime.now(UTC)),
        "counts": counts,
    }
    body = [_dump(header), *(_dump(row) for row in rows)]
    checksum = _checksum(body)
    footer = {"type": "footer", "records": len(rows), "checksum": checksum}
    data = ("\n".join([*body, _dump(footer)]) + "\n").encode("utf-8")

    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    return ExportReport(path=target, records=len(rows), counts=counts, checksum=checksum, bytes_written=len(data))


def _load_rows(path: str | Path) -> tuple[dict[str, Any], list[dict[str, Any]], str]:
    """Parse and verify an export file. Returns ``(header, rows, checksum)``."""
    lines = [line for line in Path(path).read_text(encoding="utf-8").splitlines() if line.strip()]
    if len(lines) < 2:
        raise ValueError(f"{path}: not an export file (needs a header and a footer line)")
    try:
        header = json.loads(lines[0])
        footer = json.loads(lines[-1])
    except json.JSONDecodeError as exc:
        raise ValueError(f"{path}: line is not valid JSON ({exc.msg})") from exc
    if header.get("type") != "header" or header.get("schema") != EXPORT_SCHEMA:
        raise ValueError(f"{path}: not a happyclaw-memory export (schema {header.get('schema')!r})")
    version = header.get("schema_version")
    if version != EXPORT_SCHEMA_VERSION:
        raise ValueError(f"{path}: unsupported schema_version {version!r}; this build reads {EXPORT_SCHEMA_VERSION}")
    if footer.get("type") != "footer":
        raise ValueError(f"{path}: missing footer; the export is truncated or was edited")
    body = lines[:-1]
    checksum = _checksum(body)
    if footer.get("checksum") != checksum:
        raise ValueError(
            f"{path}: checksum mismatch (footer {footer.get('checksum')!r}, file {checksum!r}); "
            "the export is corrupted or was edited after it was written"
        )
    if footer.get("records") != len(body) - 1:
        raise ValueError(f"{path}: footer claims {footer.get('records')} records, file holds {len(body) - 1}")
    rows: list[dict[str, Any]] = []
    for number, line in enumerate(body[1:], start=2):
        try:
            rows.append(json.loads(line))
        except json.JSONDecodeError as exc:
            raise ValueError(f"{path}:{number}: line is not valid JSON ({exc.msg})") from exc
    return header, rows, checksum


def _entity_from(row: dict[str, Any]) -> Entity:
    return Entity(
        id=str(row["id"]),
        entity_type=row["entity_type"],
        canonical_name=str(row["canonical_name"]),
        aliases=list(row.get("aliases") or []),
        atom_count=int(row.get("atom_count") or 0),
        created_at=_parse_dt(row.get("created_at")) or datetime.now(UTC),
        last_promoted_at=_parse_dt(row.get("last_promoted_at")),
    )


def _alias_from(row: dict[str, Any]) -> Alias:
    return Alias(
        alias=str(row["alias"]),
        entity_id=str(row["entity_id"]),
        entity_type=row["entity_type"],
        created_by=row["created_by"],
        created_at=_parse_dt(row.get("created_at")) or datetime.now(UTC),
    )


def _raw_from(row: dict[str, Any]) -> RawEvent:
    return RawEvent(
        id=str(row["id"]),
        host=str(row["host"]),
        session_id=row.get("session_id"),
        thread_id=row.get("thread_id"),
        user=row.get("user"),
        timestamp=_parse_dt(row.get("timestamp")) or datetime.now(UTC),
        event_type=row["event_type"],
        content=str(row["content"]),
        payload=dict(row.get("payload") or {}),
    )


def _candidate_from(row: dict[str, Any]) -> Candidate:
    return Candidate(
        id=str(row["id"]),
        raw_event_ids=list(row.get("raw_event_ids") or []),
        candidate_type=row["candidate_type"],
        status=row["status"],
        title=str(row["title"]),
        assertion=str(row["assertion"]),
        verbatim_quote=str(row["verbatim_quote"]),
        quote_event_id=str(row["quote_event_id"]),
        subject_name=str(row["subject_name"]),
        subject_entity_type=row["subject_entity_type"],
        target_entity_id=row.get("target_entity_id"),
        confidence=row["confidence"],
        importance=row["importance"],
        recommended_action=row["recommended_action"],
        promotion_reason=str(row["promotion_reason"]),
        extractor_version=str(row["extractor_version"]),
        created_at=_parse_dt(row.get("created_at")) or datetime.now(UTC),
        decided_at=_parse_dt(row.get("decided_at")),
        decided_by=row.get("decided_by"),
        session_id=row.get("session_id"),
        payload=dict(row.get("payload") or {}),
    )


def _atom_from(row: dict[str, Any]) -> AtomCard:
    return AtomCard(
        id=str(row["id"]),
        entity_id=str(row["entity_id"]),
        candidate_id=str(row["candidate_id"]),
        raw_event_ids=list(row.get("raw_event_ids") or []),
        assertion=str(row["assertion"]),
        verbatim_quote=str(row["verbatim_quote"]),
        quote_event_id=str(row["quote_event_id"]),
        search_terms=list(row.get("search_terms") or []),
        occurred_at=_parse_dt(row.get("occurred_at")) or datetime.now(UTC),
        confidence=row["confidence"],
        importance=row["importance"],
        created_at=_parse_dt(row.get("created_at")) or datetime.now(UTC),
        superseded_by=row.get("superseded_by"),
        deprecated_at=_parse_dt(row.get("deprecated_at")),
    )


_ROW_READERS = {
    "entity": _entity_from,
    "alias": _alias_from,
    "raw_event": _raw_from,
    "candidate": _candidate_from,
    "atom": _atom_from,
}


def _row_key(row: dict[str, Any]) -> tuple[str, str] | None:
    """Identity of a row inside its type, or ``None`` for an unknown type."""
    row_type = str(row.get("type"))
    if row_type == "alias":
        return ("alias", f"{row.get('entity_id')}|{row.get('alias')}")
    if row_type in _ROW_READERS:
        return (row_type, str(row.get("id")))
    return None


def import_memories(memory: Memory, path: str | Path, *, dry_run: bool = False) -> ImportReport:
    """Load an :func:`export_memories` file, skipping rows that already exist.

    The checksum and schema version are verified before anything is written, so
    a corrupt or foreign file cannot half-import. Import is idempotent on ids:
    re-running it over the same file adds nothing. The memory tree is rebuilt as
    leaves from the atoms; organizational parent/child structure is not part of
    the export.
    """
    _, rows, checksum = _load_rows(path)

    known: set[tuple[str, str]] = set()
    for entity in memory.list_entities(limit=SCAN_LIMIT):
        known.add(("entity", entity.id))
    for alias in memory.list_aliases(limit=SCAN_LIMIT):
        known.add(("alias", f"{alias.entity_id}|{alias.alias}"))
    for event in memory.list_raw(limit=SCAN_LIMIT):
        known.add(("raw_event", event.id))
    for candidate in memory.list_candidates(limit=SCAN_LIMIT):
        known.add(("candidate", candidate.id))
    for atom in memory.list_atoms(limit=SCAN_LIMIT, include_deprecated=True):
        known.add(("atom", atom.id))

    counts: dict[str, int] = {}
    imported = 0
    skipped = 0
    pending: list[tuple[str, dict[str, Any]]] = []
    for row in rows:
        row_type = str(row.get("type"))
        if row_type not in _ROW_READERS:
            raise ValueError(f"{path}: unknown row type {row_type!r}")
        counts[row_type] = counts.get(row_type, 0) + 1
        key = _row_key(row)
        assert key is not None
        if key in known:
            skipped += 1
            continue
        known.add(key)
        imported += 1
        pending.append((row_type, row))

    if not dry_run:
        with memory.backend.transaction():
            for row_type, row in pending:
                if row_type == "entity":
                    memory.add_entity(_entity_from(row))
                elif row_type == "alias":
                    memory.add_alias(_alias_from(row))
                elif row_type == "raw_event":
                    memory.backend.save_raw(_raw_from(row))
                elif row_type == "candidate":
                    memory.add_candidate(_candidate_from(row))
                else:
                    memory.add_atom(_atom_from(row))

    return ImportReport(
        path=Path(path),
        imported=imported,
        skipped=skipped,
        counts=counts,
        checksum=checksum,
        dry_run=dry_run,
    )


__all__ = [
    "EXPORT_SCHEMA",
    "EXPORT_SCHEMA_VERSION",
    "ExportReport",
    "ForgetPlan",
    "ImportReport",
    "MemoryFilter",
    "MemoryRecord",
    "export_memories",
    "forget",
    "forget_atoms",
    "import_memories",
    "list_memories",
]
