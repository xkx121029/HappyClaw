"""Retention policy: a TTL and capacity caps, off unless the operator arms them.

Why this exists: every extraction pass adds atoms, and nothing in a
single-person deployment ever removes them. The database grows until recall gets
slower and the backup gets bigger, and the user has no lever. This module is that
lever — but it deletes data, so it is **closed by default** and every removal is
attributed to a reason.

Three reasons can remove a fact, and the report always says which one did:

- ``ttl`` — the fact is older than ``ttl_days``.
- ``capacity_count`` — the namespace holds more than ``max_atoms`` facts.
- ``capacity_bytes`` — the fact text exceeds ``max_bytes``.

Which facts go first is :class:`RetentionStrategy`:

- ``time`` — oldest ``occurred_at`` first. Predictable, no extra state.
- ``importance`` — low before medium before high, oldest first inside a level.
- ``lru`` — the entity that recall touched longest ago goes first. Access comes
  from the thread-active-entity stack the recall pipeline already writes, so
  "least recently used" means "least recently recalled" with no extra write on
  the recall path. A backend that cannot report access falls back to ``time``
  and says so in the report.

``protect_high_importance`` (on by default) keeps ``importance == "high"`` facts
out of every eviction. A fact the user flagged as important is the one thing a
size cap must not silently eat; when protection leaves the namespace over its
cap the report says ``over_limit`` instead of quietly dropping it.

Deletion reuses :func:`happyclaw_memory.operations.lifecycle.forget_atoms`, so an
evicted fact is removed exactly like a forgotten one: row, tree leaf, candidate
text, vector entry and orphaned raw evidence.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from typing import Any, Literal

from happyclaw_memory.operations.lifecycle import SCAN_LIMIT, ForgetPlan, forget_atoms
from happyclaw_memory.types import AtomCard

RetentionStrategy = Literal["lru", "importance", "time"]

REASON_TTL = "ttl"
REASON_CAPACITY_COUNT = "capacity_count"
REASON_CAPACITY_BYTES = "capacity_bytes"

LAST_RUN_META_KEY = "retention/last_run/v1"
"""Meta key holding the last real run's report, so an operator can see what the
policy did without re-deriving it."""

_IMPORTANCE_RANK = {"low": 0, "medium": 1, "high": 2}


def _positive(value: Any, name: str) -> float | None:
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, int | float) or value <= 0:
        raise ValueError(f"retention.{name} must be a positive number, got {value!r}")
    return float(value)


def _positive_int(value: Any, name: str) -> int | None:
    number = _positive(value, name)
    return None if number is None else int(number)


@dataclass(frozen=True)
class RetentionPolicy:
    """A retention policy. All limits default to "no limit" and ``enabled`` to false."""

    enabled: bool = False
    ttl_days: float | None = None
    max_atoms: int | None = None
    max_bytes: int | None = None
    strategy: RetentionStrategy = "time"
    protect_high_importance: bool = True

    def __post_init__(self) -> None:
        if self.strategy not in ("lru", "importance", "time"):
            raise ValueError(f"retention.strategy must be lru/importance/time, got {self.strategy!r}")
        if _positive(self.ttl_days, "ttl_days") == 0:  # pragma: no cover - _positive never returns 0
            raise ValueError("retention.ttl_days must be positive")
        if self.max_atoms is not None:
            _positive_int(self.max_atoms, "max_atoms")
        if self.max_bytes is not None:
            _positive_int(self.max_bytes, "max_bytes")

    @property
    def configured(self) -> bool:
        """True when at least one limit is set, i.e. there is something to enforce."""
        return self.ttl_days is not None or self.max_atoms is not None or self.max_bytes is not None

    @classmethod
    def from_config(cls, config: dict[str, Any] | None) -> RetentionPolicy:
        """Build from a ``retention`` config block. Unknown keys are ignored."""
        cfg = dict(config or {})
        strategy = cfg.get("strategy", "time")
        if not isinstance(strategy, str):
            raise ValueError(f"retention.strategy must be a string, got {strategy!r}")
        enabled = cfg.get("enabled", False)
        if not isinstance(enabled, bool):
            raise ValueError(f"retention.enabled must be a boolean, got {enabled!r}")
        protect = cfg.get("protect_high_importance", True)
        if not isinstance(protect, bool):
            raise ValueError(f"retention.protect_high_importance must be a boolean, got {protect!r}")
        return cls(
            enabled=enabled,
            ttl_days=_positive(cfg.get("ttl_days"), "ttl_days"),
            max_atoms=_positive_int(cfg.get("max_atoms"), "max_atoms"),
            max_bytes=_positive_int(cfg.get("max_bytes"), "max_bytes"),
            strategy=strategy,  # type: ignore[arg-type]
            protect_high_importance=protect,
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "enabled": self.enabled,
            "ttl_days": self.ttl_days,
            "max_atoms": self.max_atoms,
            "max_bytes": self.max_bytes,
            "strategy": self.strategy,
            "protect_high_importance": self.protect_high_importance,
        }


@dataclass(frozen=True)
class RetentionReport:
    """What a retention run saw, removed and why."""

    enabled: bool
    dry_run: bool
    scanned: int
    protected: int
    deleted: int
    reasons: dict[str, int] = field(default_factory=dict)
    evicted_atom_ids: tuple[str, ...] = ()
    remaining: int = 0
    remaining_bytes: int = 0
    over_limit: bool = False
    notes: tuple[str, ...] = ()
    plan: ForgetPlan | None = None
    """The same plan a following real run would execute; useful for previews."""

    def to_dict(self) -> dict[str, Any]:
        return {
            "enabled": self.enabled,
            "dry_run": self.dry_run,
            "scanned": self.scanned,
            "protected": self.protected,
            "deleted": self.deleted,
            "reasons": dict(self.reasons),
            "remaining": self.remaining,
            "remaining_bytes": self.remaining_bytes,
            "over_limit": self.over_limit,
            "notes": list(self.notes),
        }


def atom_bytes(atom: AtomCard) -> int:
    """Text payload size of one fact.

    Counted as UTF-8 bytes of ``assertion`` plus ``verbatim_quote``: it is the
    part of a row whose growth the user actually controls, and it is identical on
    every backend, which a ``pg_total_relation_size`` reading is not.
    """
    return len(atom.assertion.encode("utf-8")) + len(atom.verbatim_quote.encode("utf-8"))


def _as_utc(value: datetime) -> datetime:
    return value.replace(tzinfo=UTC) if value.tzinfo is None else value.astimezone(UTC)


def _access_map(memory: Any, strategy: RetentionStrategy, notes: list[str]) -> dict[str, datetime]:
    """Last recall time per entity, for the ``lru`` strategy."""
    if strategy != "lru":
        return {}
    reader = getattr(memory.backend, "latest_entity_access", None)
    if reader is None:
        notes.append("backend has no access log; lru fell back to time order")
        return {}
    return dict(reader())


def _order(strategy: RetentionStrategy, access: dict[str, datetime]) -> Any:
    """Sort key: smallest goes first, i.e. the eviction order."""

    def key(atom: AtomCard) -> tuple[Any, ...]:
        occurred = _as_utc(atom.occurred_at)
        if strategy == "importance":
            return (_IMPORTANCE_RANK.get(atom.importance, 1), occurred, atom.id)
        if strategy == "lru":
            seen = access.get(atom.entity_id)
            return (seen or datetime.min.replace(tzinfo=UTC), occurred, atom.id)
        return (occurred, atom.id)

    return key


def enforce_retention(
    memory: Any,
    policy: RetentionPolicy,
    *,
    now: datetime | None = None,
    dry_run: bool = True,
) -> RetentionReport:
    """Apply ``policy`` to the namespace, deleting facts in eviction order.

    ``dry_run=True`` computes the full plan and reports it without writing, even
    when the policy is disabled — that is how a user previews what arming it
    would cost. A real run on a disabled policy deletes nothing.
    """
    if not policy.configured:
        raise ValueError("retention policy sets no ttl_days, max_atoms or max_bytes; nothing to enforce")
    moment = now or datetime.now(UTC)
    atoms = memory.list_atoms(limit=SCAN_LIMIT, include_deprecated=False)
    notes: list[str] = []
    protected = [a for a in atoms if policy.protect_high_importance and a.importance == "high"]
    protected_ids = {a.id for a in protected}
    candidates = [a for a in atoms if a.id not in protected_ids]

    access = _access_map(memory, policy.strategy, notes)
    order = _order(policy.strategy, access)

    reasons: dict[str, int] = {}
    evicted: list[AtomCard] = []
    evicted_ids: set[str] = set()

    def evict(atom: AtomCard, reason: str) -> None:
        evicted.append(atom)
        evicted_ids.add(atom.id)
        reasons[reason] = reasons.get(reason, 0) + 1

    if policy.ttl_days is not None:
        cutoff = moment - timedelta(days=policy.ttl_days)
        for atom in candidates:
            if _as_utc(atom.occurred_at) < cutoff:
                evict(atom, REASON_TTL)

    def live() -> list[AtomCard]:
        return [atom for atom in atoms if atom.id not in evicted_ids]

    def evictable() -> list[AtomCard]:
        return [atom for atom in live() if atom.id not in protected_ids]

    if policy.max_atoms is not None:
        need = len(live()) - policy.max_atoms
        if need > 0:
            for atom in sorted(evictable(), key=order)[:need]:
                evict(atom, REASON_CAPACITY_COUNT)

    if policy.max_bytes is not None:
        total_bytes = sum(atom_bytes(atom) for atom in live())
        if total_bytes > policy.max_bytes:
            for atom in sorted(evictable(), key=order):
                if total_bytes <= policy.max_bytes:
                    break
                evict(atom, REASON_CAPACITY_BYTES)
                total_bytes -= atom_bytes(atom)

    remaining_atoms = live()
    remaining_bytes = sum(atom_bytes(atom) for atom in remaining_atoms)
    over_limit = bool(
        (policy.max_atoms is not None and len(remaining_atoms) > policy.max_atoms)
        or (policy.max_bytes is not None and remaining_bytes > policy.max_bytes)
    )
    if over_limit:
        notes.append("still over the cap: every remaining fact is protected by protect_high_importance")

    report = RetentionReport(
        enabled=policy.enabled,
        dry_run=dry_run,
        scanned=len(atoms),
        protected=len(protected),
        deleted=len(evicted),
        reasons=reasons,
        evicted_atom_ids=tuple(a.id for a in evicted),
        remaining=len(remaining_atoms),
        remaining_bytes=remaining_bytes,
        over_limit=over_limit,
        notes=tuple(notes),
    )

    if dry_run:
        plan = forget_atoms(memory, list(report.evicted_atom_ids), dry_run=True) if evicted else None
        return RetentionReport(**{**report.__dict__, "plan": plan})
    if not policy.enabled:
        notes.append("policy disabled: nothing was deleted")
        return RetentionReport(**{**report.__dict__, "deleted": 0, "evicted_atom_ids": (), "notes": tuple(notes)})
    if not evicted:
        plan = None
    else:
        plan = forget_atoms(
            memory,
            list(report.evicted_atom_ids),
            actor="rule",
            note=f"Retention policy evicted {len(evicted)} fact(s): "
            + ", ".join(f"{reason}={count}" for reason, count in sorted(reasons.items())),
            dry_run=False,
        )
    applied = RetentionReport(**{**report.__dict__, "plan": plan, "notes": tuple(notes)})
    memory.set_meta(LAST_RUN_META_KEY, json.dumps({**applied.to_dict(), "at": moment.isoformat()}, sort_keys=True))
    return applied


__all__ = [
    "LAST_RUN_META_KEY",
    "REASON_CAPACITY_BYTES",
    "REASON_CAPACITY_COUNT",
    "REASON_TTL",
    "RetentionPolicy",
    "RetentionReport",
    "RetentionStrategy",
    "atom_bytes",
    "enforce_retention",
]
