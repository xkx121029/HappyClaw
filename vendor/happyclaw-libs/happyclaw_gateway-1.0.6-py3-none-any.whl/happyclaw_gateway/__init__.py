"""happyclaw-gateway: Multi-platform IM channel bridge for AI agents and bots.

Provides a unified abstraction for building bots across multiple IM platforms
(Feishu, QQ, WeChat, DingTalk, Discord, etc.) with a single processor function.

Quick start:
    from happyclaw_gateway import BaseChannel, ChannelManager, InboundMessage, MessageEvent

    async def my_bot(msg: InboundMessage) -> AsyncIterator[MessageEvent]:
        yield MessageEvent.text(f"Echo: {msg.text}")
        yield MessageEvent.completed()
"""

from __future__ import annotations

from typing import Any

from happyclaw_gateway.channel import BaseChannel, ChannelConfig, ChannelCredentialsError, MessageProcessor
from happyclaw_gateway.channels import SUPPORTED_CHANNEL_KINDS, ChannelKind
from happyclaw_gateway.constraints import ChannelConstraints, RateLimiter, ReplyTimeoutGuard, TypingKeepalive
from happyclaw_gateway.group_context import (
    GroupActivation,
    GroupContextConfig,
    GroupContextManager,
    GroupHistoryMode,
    GroupVisibility,
)
from happyclaw_gateway.manager import ChannelManager
from happyclaw_gateway.media import FileSystemMediaBackend, MediaBackend
from happyclaw_gateway.models import (
    AudioContent,
    ChannelSubject,
    ContentPart,
    ContentType,
    FileContent,
    GroupContext,
    GroupContextMessage,
    ImageContent,
    InboundMessage,
    MessageEvent,
    MessageEventType,
    TextContent,
    VideoContent,
)
from happyclaw_gateway.utils import Debouncer, extract_media, extract_text, has_media, has_text, merge_messages

# Channel classes that stay importable from the package root but are loaded on
# first access: importing a platform SDK for every host would drag discord.py
# into processes that only speak Feishu or Telegram.
_LAZY_EXPORTS: dict[str, str] = {
    "DiscordChannel": "happyclaw_gateway.channels.discord",
    "DiscordConfig": "happyclaw_gateway.channels.discord",
}


def __getattr__(name: str) -> Any:
    module_name = _LAZY_EXPORTS.get(name)
    if module_name is None:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
    import importlib

    value = getattr(importlib.import_module(module_name), name)
    globals()[name] = value
    return value


def __dir__() -> list[str]:
    return sorted(set(globals()) | set(_LAZY_EXPORTS))


__all__ = [
    "SUPPORTED_CHANNEL_KINDS",
    "AudioContent",
    "BaseChannel",
    "ChannelConfig",
    "ChannelConstraints",
    "ChannelCredentialsError",
    "ChannelKind",
    "ChannelManager",
    "ChannelSubject",
    "ContentPart",
    "ContentType",
    "Debouncer",
    "DiscordChannel",
    "DiscordConfig",
    "FileContent",
    "FileSystemMediaBackend",
    "GroupActivation",
    "GroupContext",
    "GroupContextConfig",
    "GroupContextManager",
    "GroupContextMessage",
    "GroupHistoryMode",
    "GroupVisibility",
    "ImageContent",
    "InboundMessage",
    "MediaBackend",
    "MessageEvent",
    "MessageEventType",
    "MessageProcessor",
    "RateLimiter",
    "ReplyTimeoutGuard",
    "TextContent",
    "TypingKeepalive",
    "VideoContent",
    "extract_media",
    "extract_text",
    "has_media",
    "has_text",
    "merge_messages",
]
