"""Persistent Feishu message-id dedup and stale-event age checks.

Feishu long connections redeliver events that were not acknowledged. The
in-memory cache on a channel instance disappears on restart and on
re-register, so ids are also stored in a small SQLite file for 24 hours.

The store runs on the channel's event loop, directly inside inbound dispatch,
so a call is on the hot path of every message. It keeps one connection per
thread open and indexes the timestamp it prunes on, so neither the prune nor
the lookup scans the table.
"""

from __future__ import annotations

import logging
import os
import sqlite3
import threading
import warnings
from contextlib import suppress
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

DEDUP_TTL_SECONDS = 24 * 60 * 60
_DEFAULT_MAX_MSG_AGE_SECONDS = 180.0
_MILLISECOND_THRESHOLD = 10**11

_ENV_PREFIX = "HAPPYCLAW_"
_LEGACY_ENV_PREFIX = "OCTOP_"
_LEGACY_WARNED: set[str] = set()
_LEGACY_WARNED_LOCK = threading.Lock()

_SCHEMA = """
CREATE TABLE IF NOT EXISTS feishu_seen (
    channel_id TEXT NOT NULL,
    message_id TEXT NOT NULL,
    seen_at REAL NOT NULL,
    PRIMARY KEY (channel_id, message_id)
)
"""

_SCHEMA_INDEX = "CREATE INDEX IF NOT EXISTS feishu_seen_seen_at ON feishu_seen (seen_at)"

_STORES: dict[str, FeishuDedupStore] = {}
_STORES_LOCK = threading.Lock()


def read_env(name: str) -> str:
    """Return ``HAPPYCLAW_<name>``, falling back to the legacy ``OCTOP_<name>``.

    The ``HAPPYCLAW_`` prefix was introduced in 1.0.6. The legacy prefix is
    still honoured so existing ``.env`` files keep working, and it warns once
    per variable per process so the migration is visible without log spam.
    """
    raw = os.environ.get(_ENV_PREFIX + name)
    if raw is not None:
        return raw.strip()
    legacy_name = _LEGACY_ENV_PREFIX + name
    raw = os.environ.get(legacy_name)
    if raw is None:
        return ""
    with _LEGACY_WARNED_LOCK:
        first = legacy_name not in _LEGACY_WARNED
        _LEGACY_WARNED.add(legacy_name)
    if first:
        warnings.warn(
            f"{legacy_name} is deprecated and will be removed in 2.0; use {_ENV_PREFIX + name}",
            DeprecationWarning,
            stacklevel=3,
        )
    return raw.strip()


def resolve_dedup_db_path(explicit: str) -> str:
    """Return the SQLite path from config or ``HAPPYCLAW_FEISHU_DEDUP_DB``.

    An empty result means this process keeps ids in memory only.
    """
    path = (explicit or "").strip()
    if path:
        return path
    return read_env("FEISHU_DEDUP_DB")


def max_message_age_seconds() -> float:
    """Age gate from ``HAPPYCLAW_FEISHU_MAX_MSG_AGE_SECONDS``.

    The default is 180 seconds. ``0`` turns the gate off. An invalid value
    falls back to the default.
    """
    raw = read_env("FEISHU_MAX_MSG_AGE_SECONDS")
    if not raw:
        return _DEFAULT_MAX_MSG_AGE_SECONDS
    try:
        value = float(raw)
    except ValueError:
        logger.warning("ignoring invalid %sFEISHU_MAX_MSG_AGE_SECONDS=%r", _ENV_PREFIX, raw)
        return _DEFAULT_MAX_MSG_AGE_SECONDS
    if value < 0:
        return _DEFAULT_MAX_MSG_AGE_SECONDS
    return value


def message_create_time_seconds(raw: Any) -> float | None:
    """Parse a Feishu ``create_time`` into Unix seconds.

    Feishu sends milliseconds. Values that are already in seconds are accepted.
    Missing or non-positive values return ``None`` so the caller does not
    treat them as ancient messages.
    """
    if raw is None:
        return None
    text = str(raw).strip()
    if not text:
        return None
    try:
        value = float(int(text))
    except (TypeError, ValueError):
        return None
    if value <= 0:
        return None
    if value >= _MILLISECOND_THRESHOLD:
        return value / 1000.0
    return value


class FeishuDedupStore:
    """SQLite set of recently handled ``(channel_id, message_id)`` pairs."""

    def __init__(self, path: str) -> None:
        self.path = str(Path(path).expanduser())
        self._lock = threading.Lock()
        self._local = threading.local()

    @property
    def _connection(self) -> sqlite3.Connection:
        """Return this thread's open connection, opening and migrating once."""
        conn: sqlite3.Connection | None = getattr(self._local, "conn", None)
        if conn is not None:
            return conn
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(self.path, timeout=5)
        # WAL keeps a commit from fsyncing the whole journal per event; the
        # setting is per-database and is ignored when the filesystem cannot
        # support it (network shares), so a failure here is not fatal.
        with suppress(sqlite3.Error):
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA synchronous=NORMAL")
        conn.execute(_SCHEMA)
        conn.execute(_SCHEMA_INDEX)
        conn.commit()
        self._local.conn = conn
        return conn

    def already_seen(self, channel_id: str, message_id: str, *, now: float, ttl_seconds: float) -> bool:
        """Return True when this id was stored within the TTL. New ids are inserted."""
        with self._lock:
            conn = self._connection
            try:
                conn.execute("DELETE FROM feishu_seen WHERE seen_at < ?", (now - ttl_seconds,))
                row = conn.execute(
                    "SELECT 1 FROM feishu_seen WHERE channel_id = ? AND message_id = ?",
                    (channel_id, message_id),
                ).fetchone()
                if row is not None:
                    conn.commit()
                    return True
                conn.execute(
                    "INSERT OR IGNORE INTO feishu_seen (channel_id, message_id, seen_at) VALUES (?, ?, ?)",
                    (channel_id, message_id, now),
                )
                conn.commit()
                return False
            except sqlite3.Error:
                conn.rollback()
                raise

    def close(self) -> None:
        """Close this thread's connection so the file can be moved or deleted."""
        conn: sqlite3.Connection | None = getattr(self._local, "conn", None)
        if conn is not None:
            conn.close()
            self._local.conn = None


def open_dedup_store(path: str) -> FeishuDedupStore | None:
    """Open (and cache) a store. Return None when the path cannot be created."""
    resolved = str(Path(path).expanduser())
    with _STORES_LOCK:
        cached = _STORES.get(resolved)
        if cached is not None:
            return cached
        store = FeishuDedupStore(resolved)
        try:
            store._connection.execute("SELECT 1 FROM feishu_seen LIMIT 1").fetchone()
        except (OSError, sqlite3.Error) as exc:
            logger.warning("Feishu dedup store unavailable at %s: %s", resolved, exc)
            store.close()
            return None
        _STORES[resolved] = store
        return store


def reset_dedup_stores() -> None:
    """Close every cached store. Used by tests and by clean shutdown."""
    with _STORES_LOCK:
        for store in _STORES.values():
            store.close()
        _STORES.clear()


__all__ = [
    "DEDUP_TTL_SECONDS",
    "FeishuDedupStore",
    "max_message_age_seconds",
    "message_create_time_seconds",
    "open_dedup_store",
    "reset_dedup_stores",
    "resolve_dedup_db_path",
]
