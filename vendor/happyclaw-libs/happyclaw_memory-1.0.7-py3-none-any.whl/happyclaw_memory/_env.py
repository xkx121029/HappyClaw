"""Environment-variable access with a deprecation path for the pre-rename prefix.

``HAPPYCLAW_*`` and ``HAPPYCLAWMEMORY_*`` are the supported names. A variable
that was already documented under the old ``OCTOP_*`` / ``OCTOPMEMORY_*``
prefix still resolves, but the first read from an old name emits a
:class:`DeprecationWarning` naming its replacement, so a running deployment
keeps working while it is told to migrate.
"""

from __future__ import annotations

import os
import warnings

# Longest prefix first: OCTOPMEMORY_* must not be read as a OCTOP_* variable.
_PREFIXES = (
    ("HAPPYCLAWMEMORY_", "OCTOPMEMORY_"),
    ("HAPPYCLAW_", "OCTOP_"),
)

_warned: set[str] = set()

__all__ = ["getenv", "legacy_name", "names", "warn_legacy_env"]


def legacy_name(name: str) -> str | None:
    """Return the pre-rename spelling of ``name``, or ``None`` when it has none."""
    for new, old in _PREFIXES:
        if name.startswith(new):
            return old + name[len(new) :]
    return None


def names(name: str) -> list[str]:
    """Environment names backing ``name``, new name first (for ``click``'s ``envvar=``)."""
    old = legacy_name(name)
    return [name, old] if old is not None else [name]


def _warn(replacement: str, old: str) -> None:
    if old in _warned:
        return
    _warned.add(old)
    warnings.warn(
        f"{old} is deprecated and will stop being read in a future release; rename it to {replacement}.",
        DeprecationWarning,
        stacklevel=3,
    )


def getenv(name: str, default: str | None = None) -> str | None:
    """Read ``name``, falling back to its pre-rename spelling."""
    value = os.environ.get(name)
    if value is not None:
        return value
    old = legacy_name(name)
    if old is not None:
        value = os.environ.get(old)
        if value is not None:
            _warn(name, old)
            return value
    return default


def warn_legacy_env() -> None:
    """Warn about legacy variables that an option resolves without going through :func:`getenv`.

    ``click`` reads ``envvar=`` lists itself, so a command group calls this once
    on entry to keep the deprecation visible for those options too.
    """
    for old_name in list(os.environ):
        for new_prefix, old_prefix in _PREFIXES:
            if old_name.startswith(old_prefix):
                replacement = new_prefix + old_name[len(old_prefix) :]
                if replacement not in os.environ:
                    _warn(replacement, old_name)
                break
