"""Latency timeout primitives (D43-A — 100ms soft / 200ms hard).

The recall pipeline is on the user's per-turn critical path. Default
budgets:

- **atom FTS** ≤ 50ms
- **page lookup** ≤ 30ms
- **raw FTS** ≤ 30ms
- **total recall** ≤ 200ms (hard kill — return whatever's accumulated)

We expose two helpers:

- :func:`with_deadline` — context manager that runs a callable inside
  a thread and aborts if it doesn't return within ``budget_ms``. The
  thread is allowed to finish in the background (we can't kill native
  SQLite calls cleanly), but we don't wait for it.
- :class:`Stopwatch` — start / split timer to track elapsed budget
  across the pipeline so each stage knows the remaining slice.

Implementation note: we explicitly avoid ``signal.alarm`` because it
breaks under threading and on Windows. ``concurrent.futures.Future.result(timeout)``
is the simplest correct primitive.
"""

from __future__ import annotations

import concurrent.futures
import threading
import time
from collections.abc import Callable
from dataclasses import dataclass, field

DEFAULT_TOTAL_BUDGET_MS = 200
"""Hard wall on the entire recall call."""

DEFAULT_ATOM_BUDGET_MS = 50
DEFAULT_PAGE_BUDGET_MS = 30
DEFAULT_RAW_BUDGET_MS = 30

_WORKERS = 4
"""Worker threads shared by every recall stage in the process.

Spawning a thread per stage looked cheap and is not: on a Windows host with
real-time AV scanning, one `ThreadPoolExecutor(max_workers=1)` submit cost
~100ms, which the `Stopwatch` then charged to the *global* 200ms budget. Two
sources were enough to exhaust it, and the later source was dropped with
`TimeoutExceededError` even though the work it was skipping took milliseconds.
Four slots cover the sequential stages a single recall runs plus an abandoned
one, so a stage that genuinely overruns cannot starve the next query.
"""

_pool_holder: dict[str, concurrent.futures.ThreadPoolExecutor] = {}
_pool_lock = threading.Lock()


def _executor() -> concurrent.futures.ThreadPoolExecutor:
    """Lazily create the shared stage pool (the first recall pays the spawn)."""
    pool = _pool_holder.get("pool")
    if pool is not None:
        return pool
    with _pool_lock:
        pool = _pool_holder.get("pool")
        if pool is None:
            pool = concurrent.futures.ThreadPoolExecutor(max_workers=_WORKERS, thread_name_prefix="recall")
            _pool_holder["pool"] = pool
        return pool


def shutdown_executor() -> None:
    """Join and drop the shared pool. Tests use this; hosts need not call it."""
    with _pool_lock:
        pool = _pool_holder.pop("pool", None)
    if pool is not None:
        pool.shutdown(wait=True, cancel_futures=True)


class TimeoutExceededError(Exception):
    """Raised when one recall stage exceeds its time budget.

    Raised when a stage exceeds its individual budget. The caller
    typically catches and skips to the next source rather than
    propagating to the user."""

    def __init__(self, stage: str, budget_ms: int):
        super().__init__(f"stage {stage!r} exceeded {budget_ms}ms budget")
        self.stage = stage
        self.budget_ms = budget_ms


def with_deadline[T](
    fn: Callable[[], T],
    *,
    stage: str,
    budget_ms: int,
) -> T:
    """Run ``fn()`` in a worker thread, abort if it exceeds ``budget_ms``.

    Returns ``fn()``'s value on success. Raises :class:`TimeoutExceededError`
    on timeout. The worker is left running in the background; callers MUST
    tolerate the duplicate work (idempotent reads only).

    Stages share one process-wide pool rather than spawning a thread each.
    Thread creation is the largest single cost of a fast stage on hosts with
    real-time antivirus, and it is charged to the caller's remaining budget.
    """
    if budget_ms <= 0:
        # Caller has already burned the budget — short-circuit.
        raise TimeoutExceededError(stage=stage, budget_ms=budget_ms)
    future = _executor().submit(fn)
    try:
        return future.result(timeout=budget_ms / 1000.0)
    except concurrent.futures.TimeoutError as exc:
        raise TimeoutExceededError(stage=stage, budget_ms=budget_ms) from exc


@dataclass
class Stopwatch:
    """Tracks elapsed time so each stage knows the remaining global budget.

    Usage::

        sw = Stopwatch(total_budget_ms=200)
        try:
            atoms = with_deadline(fetch_atoms, stage="atom",
                                  budget_ms=min(50, sw.remaining_ms))
        finally:
            sw.split("atom")
        # ...continue, each stage clamps to remaining...
    """

    total_budget_ms: int = DEFAULT_TOTAL_BUDGET_MS
    started_at: float = field(default_factory=time.monotonic)
    splits: dict[str, float] = field(default_factory=dict)

    @property
    def elapsed_ms(self) -> int:
        return int((time.monotonic() - self.started_at) * 1000.0)

    @property
    def remaining_ms(self) -> int:
        return max(0, self.total_budget_ms - self.elapsed_ms)

    @property
    def expired(self) -> bool:
        return self.remaining_ms <= 0

    def split(self, label: str) -> None:
        """Record a stage boundary for diagnostics."""
        self.splits[label] = (time.monotonic() - self.started_at) * 1000.0


__all__ = [
    "DEFAULT_ATOM_BUDGET_MS",
    "DEFAULT_PAGE_BUDGET_MS",
    "DEFAULT_RAW_BUDGET_MS",
    "DEFAULT_TOTAL_BUDGET_MS",
    "Stopwatch",
    "TimeoutExceededError",
    "shutdown_executor",
    "with_deadline",
]
