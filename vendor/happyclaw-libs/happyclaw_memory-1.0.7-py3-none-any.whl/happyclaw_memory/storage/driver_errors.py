"""Exception groups narrow enough for pylint ``broad-except``.

``Exception`` and ``BaseException`` are not included. Callers that must
roll back on any failure use ``try`` / ``finally`` instead of a broad
``except``.

The database and vector groups are **derived at call time** rather than
frozen at import: an optional backend's exception class joins the group only
once that backend has been imported. Reading ``sys.modules`` instead of
importing is what keeps ``import happyclaw_memory`` free of psycopg and its libpq
load — code that can raise a psycopg error has necessarily imported psycopg, so
the class is present by the time the group is evaluated.

The upper-case names remain importable for compatibility, but they resolve
through a module ``__getattr__`` and therefore describe the group *as of that
statement*. Code inside this package reads the live group from the module:
``except driver_errors.DRIVER_ERRORS:``.
"""

from __future__ import annotations

import json
import sqlite3
import sys
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    # Declared for readers and type checkers; resolved at runtime by
    # ``__getattr__`` so each access reflects the groups as they are *now*.
    DRIVER_ERRORS: tuple[type[BaseException], ...]
    REPORTABLE_ERRORS: tuple[type[BaseException], ...]
    VECTOR_ERRORS: tuple[type[BaseException], ...]

__all__ = [
    "DRIVER_ERRORS",
    "PAYLOAD_ERRORS",
    "REPORTABLE_ERRORS",
    "VECTOR_ERRORS",
    "driver_errors",
    "payload_errors",
    "reportable_errors",
    "vector_errors",
]

_BASE_DRIVER_ERRORS: tuple[type[BaseException], ...] = (
    sqlite3.Error,
    OSError,
    TimeoutError,
    RuntimeError,
)
"""Query, filesystem, timeout, and operational runtime failures that need no
optional dependency."""

PAYLOAD_ERRORS: tuple[type[BaseException], ...] = (
    ValueError,
    KeyError,
    IndexError,
    LookupError,
    TypeError,
    AttributeError,
    UnicodeError,
    ArithmeticError,
    json.JSONDecodeError,
)
"""Bad payloads on top of driver failures. Programming errors such as
AssertionError are still absent."""


def _loaded_error(module: str, name: str) -> tuple[type[BaseException], ...]:
    """An error class from an optional dependency that is already imported."""
    loaded = sys.modules.get(module)
    if loaded is None:
        return ()
    candidate = getattr(loaded, name, None)
    if isinstance(candidate, type) and issubclass(candidate, BaseException):
        return (candidate,)
    return ()


def driver_errors() -> tuple[type[BaseException], ...]:
    """Driver failures, including psycopg's once the PostgreSQL extra is loaded."""
    return (*_BASE_DRIVER_ERRORS, *_loaded_error("psycopg", "Error"))


def payload_errors() -> tuple[type[BaseException], ...]:
    """Bad-payload failures; a plain alias so callers can read symmetrically."""
    return PAYLOAD_ERRORS


def reportable_errors() -> tuple[type[BaseException], ...]:
    """Driver + payload failures: boundaries that report rather than crash."""
    return (*driver_errors(), *PAYLOAD_ERRORS)


def vector_errors() -> tuple[type[BaseException], ...]:
    """Driver failures plus the vector clients' own errors, when loaded."""
    return (
        *driver_errors(),
        ValueError,
        KeyError,
        IndexError,
        LookupError,
        UnicodeError,
        json.JSONDecodeError,
        *_loaded_error("chromadb.errors", "ChromaError"),
        *_loaded_error("qdrant_client.http.exceptions", "UnexpectedResponse"),
        *_loaded_error("qdrant_client.http.exceptions", "ResponseHandlingException"),
    )


_LAZY_GROUPS = {
    "DRIVER_ERRORS": driver_errors,
    "REPORTABLE_ERRORS": reportable_errors,
    "VECTOR_ERRORS": vector_errors,
}


def __getattr__(name: str) -> object:
    """Resolve the compatibility names against the groups as they are now."""
    factory = _LAZY_GROUPS.get(name)
    if factory is not None:
        return factory()
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
